using UnityEngine;
using System.Collections;

public class PushMe : MonoBehaviour {
	public static Vector3 directionToPush = Vector3.zero;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(directionToPush!=Vector3.zero)
		{
			Debug.Log("Attemping to push me");
			if(this.GetComponent<Rigidbody>()==null)
			{
				this.gameObject.AddComponent<Rigidbody>();
			}
			if((this.transform.position.y-4f)<0) //only push the base layer of blocks
			{
				this.rigidbody.velocity = directionToPush;
			}
			this.gameObject.layer=2; //add to the ignore raycast layer so that we don't spawn more blocks on top of the falling block
			Destroy(this.gameObject, 30f);
		}
	}
	void LateUpdate () {
		directionToPush=Vector3.zero;
	}
}

using UnityEngine;
using System.Collections;

public class SpawnBlock : MonoBehaviour {
	public Transform blockPrefab;
	public Vector3 offSetVector = new Vector3(0,3,0); //adjust this value to change the distance between the new block and the old block
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void DoSpawning (GameObject objectToSpawnOnTopOf) {
		GameObject newBlock = GameObject.Instantiate(blockPrefab, objectToSpawnOnTopOf.transform.position+offSetVector*objectToSpawnOnTopOf.GetComponent<StoreHeight>().height, Quaternion.identity) as GameObject;
		objectToSpawnOnTopOf.GetComponent<StoreHeight>().height++;
		if(objectToSpawnOnTopOf.GetComponent<StoreHeight>().height==1)
		{
			objectToSpawnOnTopOf.GetComponent<StoreHeight>().firstPhysical=newBlock;
		}
		Destroy(newBlock, 45f);
	}
}

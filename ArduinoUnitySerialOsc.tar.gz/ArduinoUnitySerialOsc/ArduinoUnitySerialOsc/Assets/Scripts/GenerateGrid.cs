using UnityEngine;
using System.Collections;

public class GenerateGrid : MonoBehaviour {
	public GameObject BaseBlock;
	// Use this for initialization
	void Start () {
		Vector3 initialPosition = new Vector3(-15f, 1f, -24.5f);
		for(int i=0; i<=10; i++)
		{
			initialPosition.x=-15f;
			for(int ii=0; ii<=10; ii++)
			{
				GameObject next = GameObject.Instantiate(BaseBlock, initialPosition, Quaternion.identity) as GameObject;
				next.name=""+i+""+ii;
				initialPosition.x+=3;
			}
			initialPosition.z+=3;
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

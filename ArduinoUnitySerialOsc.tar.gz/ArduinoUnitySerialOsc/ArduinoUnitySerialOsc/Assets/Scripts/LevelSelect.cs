using UnityEngine;
using System.Collections;

public class LevelSelect : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnGUI() {
		if(GUI.Button(new Rect(300,150,150,25), "Serial Data Version"))
		{
			Application.LoadLevel("MainScene");
		}
		if(GUI.Button(new Rect(300,175,150,25), "OSC Version"))
		{
			Application.LoadLevel("OSCScene");
		}
		if(GUI.Button(new Rect(300,200,150,25), "Mouse Version"))
		{
			Application.LoadLevel("MouseScene");
		}
	}
}

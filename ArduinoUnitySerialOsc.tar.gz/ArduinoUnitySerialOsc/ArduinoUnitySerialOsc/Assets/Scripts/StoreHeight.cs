using UnityEngine;
using System.Collections;

public class StoreHeight : MonoBehaviour {
	public int height=1;
	public static bool resetheight;
	public GameObject firstPhysical;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(resetheight)
		{
			height=1;
		}
	
	}
	void LateUpdate ()
	{
		resetheight=false;	
	}
}

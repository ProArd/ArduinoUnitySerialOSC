using UnityEngine;
using System.Collections;
using System;
public class DaBomb : MonoBehaviour {
	public DateTime bombStartTime;
	public GameObject bombPrefab;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void ReleaseBomb(Vector3 bombPosition)
	{
		TimeSpan timeHeldDown = System.DateTime.Now-bombStartTime;
		double bombsize = 1+timeHeldDown.TotalSeconds;
		if(bombsize>10) //we have a cap on the charge up
		{
			bombsize=10;
		}
		bombPosition.y = 40; //place bomb directly above camera and let physics engine handle the bombing
		GameObject newBomb = GameObject.Instantiate(bombPrefab, bombPosition, Quaternion.identity) as GameObject;
		newBomb.transform.localScale=newBomb.transform.localScale*(float)bombsize;
		StoreHeight.resetheight=true;
		Destroy(newBomb, 30f);
	}
}

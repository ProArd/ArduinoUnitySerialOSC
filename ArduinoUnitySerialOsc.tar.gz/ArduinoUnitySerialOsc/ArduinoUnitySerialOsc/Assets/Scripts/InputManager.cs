using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
//using System.IO.Ports;
using LitJson;
using System.Text.RegularExpressions;
public class InputManager : MonoBehaviour {
	SpawnBlock spawnManager;
	DaBomb bombManager;
	//SerialPort stream;
	JsonData inputFromArduino;
	float accelNoiseThreshold = 20f;
	int lastValOfButton=0;
	public GameObject mainCam;
	public Vector3 baseCamPosition = new Vector3(-24f, 38f,-32f);
	public string inputType;
	private Dictionary<string, ServerLog> oscServers = new Dictionary<string, ServerLog>();
	public GameObject cursor;
	//ServerLog theServer;
	// Use this for initialization
	void Start () {
	/*	if(inputType=="Serial")
		{
			string[] ports = SerialPort.GetPortNames();
			stream = new SerialPort(ports[0], 57600);
			stream.Open();
			stream.Write (" ");
			StartCoroutine("SlowUpdate");
		}
		
		else */ 
		if(inputType=="OSC")
		{
			//osc code here
			OSCHandler.Instance.Init();
			StartCoroutine("OSCUpdate");
		}
		spawnManager = GetComponent<SpawnBlock>();
		bombManager = GetComponent<DaBomb>();

	}
	/*
	IEnumerator SlowUpdate() //since the arduino only updates its input every .25 seconds we can have a slower update that runs on a .25sec cycle
	{
		while(true)
		{
			string val = stream.ReadLine();
			Debug.Log(val);
			inputFromArduino = JsonMapper.ToObject(val);
			yield return new WaitForSeconds(.25f);
		}
	}
	*/
	IEnumerator OSCUpdate()
	{
		while(true)
		{
			//theServer = OSCHandler.Instance.Servers["UnityOSCServer"];
			OSCHandler.Instance.UpdateLogs();
			oscServers = OSCHandler.Instance.Servers;
			
			 foreach(KeyValuePair<string, ServerLog> item in oscServers)
        {
            // If we have received at least one packet,
            // show the last received from the log in the Debug console
            if(item.Value.log.Count > 0) 
            {
                int lastPacketIndex = item.Value.packets.Count - 1;

                Debug.Log(String.Format("SERVER: {0} ADDRESS: {1} VALUE 0: {2}", 
                                        item.Key, // Server name
                                        item.Value.packets[lastPacketIndex].Address, // OSC address
                                        item.Value.packets[lastPacketIndex].Data[0].ToString())); //First data value
					
				Debug.Log("item.Key: " + item.Key);
				Debug.Log("item.Value: " + item.Value);
				Debug.Log("item.Value.packets[lastPacketIndex].Data[0].ToString()): " + item.Value.packets[lastPacketIndex].Data[0].ToString());		
				string oscData = item.Value.packets[lastPacketIndex].Data[0].ToString();
				inputFromArduino=JsonMapper.ToObject(oscData);
				UnityEngine.Debug.Log(inputFromArduino);
				
            }
        }
			yield return new WaitForSeconds(.25f);
		}	
	}
	
	void Update()
	{
		if(inputType=="Mouse")
		{
			RaycastHit hit;
			Vector3 hitPoint = new  Vector3(0,0,0); 
			if(Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit))
			{
				if(hit.transform.name!="Plane")
				{
					if(Input.GetMouseButton(0))
					{
						spawnManager.DoSpawning(hit.transform.gameObject);
					}
				}
				hitPoint = hit.point;
			}
			hitPoint.y=40;
			if(Input.GetKeyDown(KeyCode.A)) //push left
			{
				Debug.Log("Pushing left!");
				PushMe.directionToPush = new Vector3(-30,0,0);
			}
			if(Input.GetKeyDown(KeyCode.D)) //pushing right
			{
				Debug.Log("Pushing right!");
				PushMe.directionToPush = new Vector3(30,0,0);
			}
			if(Input.GetKeyDown(KeyCode.W))
			{
				Debug.Log("Pushing forward!");
				PushMe.directionToPush = new Vector3(0,0,30);
			}
			if(Input.GetKeyDown(KeyCode.S))
			{
				Debug.Log("Pushing backwards!");
				PushMe.directionToPush = new Vector3(0,0,-30);
			}
			if(Input.GetMouseButtonDown(1))
			{
				bombManager.bombStartTime=System.DateTime.Now;
			}
			if(Input.GetMouseButtonUp(1))
			{
				bombManager.ReleaseBomb(hitPoint);
			}
		}
		else
		{
			Debug.Log("inputFromArduino:joyX " + inputFromArduino["joyX"]);
			Debug.Log("inputFromArduino:joyY " + inputFromArduino["joyY"]);
			Debug.Log("inputFromArduino:camX " + inputFromArduino["camX"]);
			Debug.Log("inputFromArduino:camY " + inputFromArduino["camY"]);
			Debug.Log("inputFromArduino:angX " + inputFromArduino["angX"]);
			Debug.Log("inputFromArduino:anyY " + inputFromArduino["angY"]);
			Debug.Log("inputFromArduino:angZ " + inputFromArduino["angZ"]);

			Vector2 joyStickPosition = new Vector2((int)inputFromArduino["joyX"]/100, (int)inputFromArduino["joyY"]/100);
			GameObject selectedObject = GameObject.Find(""+joyStickPosition.x+""+joyStickPosition.y);
			cursor.transform.position = selectedObject.transform.position+new Vector3(0f,40f,0f);
			if((int)inputFromArduino["but2"]==1)
			{
				spawnManager.DoSpawning(selectedObject);
			}
			Vector3 directionToPush = new Vector3((float)(int)inputFromArduino["angX"]+4, (float)(int)inputFromArduino["angY"]+18, (float)(int)inputFromArduino["angZ"]-5);
			Vector3 newCamPosition = baseCamPosition;
			newCamPosition.x+=(int)inputFromArduino["camX"]/21; //21 is a playtested value
			newCamPosition.z+=(int)inputFromArduino["camY"]/21;
			mainCam.transform.position=newCamPosition;
			Debug.Log("Direction to push:" + directionToPush.magnitude);
			Debug.Log("Noise threshold" + accelNoiseThreshold);
			if(directionToPush.magnitude>accelNoiseThreshold)
			{
				Debug.Log("Pushing me");
				PushMe.directionToPush=directionToPush;
				StoreHeight.resetheight=true;
			}
			if(lastValOfButton==0 && (int)inputFromArduino["but1"]==1)
			{
				lastValOfButton=1;
				bombManager.bombStartTime=System.DateTime.Now;
			}
			if(lastValOfButton==1 && (int)inputFromArduino["but1"]==0)
			{
				Vector3 bombCoordinates = selectedObject.transform.position;
				bombCoordinates.y=40;
				bombManager.ReleaseBomb(bombCoordinates);
				lastValOfButton = 0;
			}
			
		}
	}
}
